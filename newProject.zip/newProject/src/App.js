import React, { useState, useEffect } from "react";
import SignUp from "./SignUp";
import Login from "./Login";
import DashBoard from "./DashBoard";
import "./App.css";
import { BrowserRouter as Router, Route, NavLink } from "react-router-dom";
import PrivateRoute from "./PrivateRoute";

function App() {
  return (
    <Router>
      <Route path="/" component={SignUp} exact />
      <Route path="/login" component={Login} />
      <PrivateRoute path="/dashboard" Component={DashBoard} />
    </Router>
  );
}

export default App;
