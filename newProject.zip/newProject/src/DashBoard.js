import React, { useState, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import { ExportToCsv } from "export-to-csv-file";
import { useHistory } from "react-router-dom";

function DashBoard() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [query, setQuery] = useState("");
  const [items, setItems] = useState([]);
  const [searchClicked, setSearchClicked] = useState(false);
  const [searchResult, setSearchResult] = useState([]);

  const history = useHistory();

  const options = {
    fieldSeparator: ",",
    quoteStrings: '"',
    decimalSeparator: ".",
    showLabels: true,
    showTitle: true,
    title: "My Awesome CSV",
    useTextFile: false,
    useBom: true,
    useKeysAsHeaders: true,
    // headers: ['Column 1', 'Column 2', etc...] <-- Won't work with useKeysAsHeaders present!
  };

  useEffect(() => {
    if (query.length == 0) {
      setSearchClicked(false);
      setItems([...items]);
    }
  }, [query]);

  const handleInput = (e) => {
    const { name, value } = e.target;
    if (name == "name") {
      setName(value);
    } else if (name == "price") {
      setPrice(value);
    } else {
      setQuery(value);
    }
  };

  const handleItems = () => {
    const data = [{ name: name, price: parseInt(price), id: uuidv4() }];
    setItems([...items, ...data]);
    setPrice("");
    setName("");
  };

  const handleDelete = (id) => {
    let filteredData = items.filter((item, i) => item.id != id);
    setItems([...filteredData]);
  };

  const handleSort = (type) => {
    if (type == "name") {
      let sortedData = items.sort((a, b) => {
        if (a.name < b.name) {
          return -1;
        }
        if (a.name > b.name) {
          return 1;
        }
        return 0;
      });
      setItems([...sortedData]);
    } else {
      console.log("dfsdf");
      items.sort(function (a, b) {
        return a.price - b.price;
      });

      setItems([...items]);
    }
  };

  const exportHandler = () => {
    const csvExporter = new ExportToCsv(options);
    csvExporter.generateCsv(items);
  };

  const handleSearch = () => {
    let searchedResults = items.filter((item) => item.name.includes(query));
    setSearchResult([...searchedResults]);
    setSearchClicked(true);
  };

  const getTable = (item, i) => {
    return (
      <tr>
        <td>{item.name}</td>
        <td>{item.price}</td>
        <td>
          {" "}
          <button onClick={() => handleDelete(item.id)}>Delete</button>
        </td>
      </tr>
    );
  };

  return (
    <div className="container">
      <div>
        <input
          value={name}
          type="text"
          name="name"
          placeholder="Name..."
          onChange={handleInput}
          className="user-name"
        ></input>

        <input
          value={price}
          type="number"
          name="price"
          placeholder="Price..."
          onChange={handleInput}
          className="user-price"
        ></input>
        <button style={{ marginLeft: 5 }} className="btn" onClick={handleItems}>
          Add Item
        </button>
      </div>

      {items.length > 0 ? (
        <div className="list_group">
          <input
            type="text"
            placeholder="search..."
            name="search"
            value={query}
            onChange={handleInput}
            className="user-name"
          />
          <button
            className="btn"
            style={{ marginLeft: 5 }}
            onClick={handleSearch}
          >
            Search
          </button>
          <table>
            <tr>
              <th onClick={() => handleSort("name")}>Name</th>
              <th onClick={() => handleSort("price")}>Price</th>
              <th>Action</th>
            </tr>
            {searchClicked
              ? searchResult.map((item, i) => getTable(item, i))
              : items.map((item, i) => getTable(item, i))}
          </table>
          <button
            className="btn"
            style={{ marginTop: 4 }}
            onClick={exportHandler}
          >
            Export Data
          </button>
        </div>
      ) : (
        <h3>No items to show!!!</h3>
      )}

      <button
        className="btn"
        onClick={() => {
          localStorage.removeItem("isAuthenticated");
          history.push("/login");
        }}
      >
        Logout
      </button>
    </div>
  );
}

export default DashBoard;
