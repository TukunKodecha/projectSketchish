import React, { useState } from "react";
import { useHistory } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const history = useHistory();

  const handleEmail = (e) => {
    setEmail(e.target.value);
  };

  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = () => {
    let localUsers = localStorage.getItem("users");
    if (localUsers) {
      let parsedUsers = JSON.parse(localUsers);
      let fetchedUser = parsedUsers.find((user) => user.email == email); //{}
      if (fetchedUser) {
        if (fetchedUser.password == password) {
          localStorage.setItem("isAuthenticated", true);
          history.push("/dashboard");
        } else {
          alert("please enter correct password");
        }
      } else {
        alert("User not found!");
      }
    } else {
      alert("There is no any user in db!");
    }
  };
  return (
    <div className="container">
      <h1>Login</h1>
      <div className="email">
        <label style={{ fontWeight: "bolder", color: "rgb(121, 214, 137)" }}>
          Email
        </label>
        <br />
        <input
          type="email"
          name="name"
          placeholder="Type your email"
          className="user-email"
          onChange={handleEmail}
        ></input>
      </div>

      <div className="password">
        <label style={{ fontWeight: "bolder", color: "rgb(121, 214, 137)" }}>
          Password{" "}
        </label>
        <br />
        <input
          type="password"
          name="name"
          placeholder="Type your password"
          className="user-password"
          onChange={handlePassword}
        ></input>
      </div>
      <div>
        <button className="btn" onClick={handleLogin}>
          Login
        </button>
      </div>
    </div>
  );
}

export default Login;
