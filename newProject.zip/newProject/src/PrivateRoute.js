import React from "react";
import { Route, Redirect } from "react-router-dom";

function PrivateRoute({ path, Component }) {
  return (
    <Route
      path={path}
      render={(props) => {
        let isLoggedIn = localStorage.getItem("isAuthenticated");
        return isLoggedIn ? <Component /> : <Redirect to={"/login"} />;
      }}
    />
  );
}

export default PrivateRoute;
