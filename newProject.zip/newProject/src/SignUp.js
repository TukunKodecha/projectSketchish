import React, { useState } from "react";
import "./App.css";
import { useHistory } from "react-router-dom";

function SignUp() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const history = useHistory();

  const handleName = (e) => {
    setName(e.target.value);
  };

  const handleEmail = (e) => {
    setEmail(e.target.value);
  };
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleSignUp = () => {
    if (name.length == 0 || email.length == 0 || password.length == 0) {
      alert("Please fill all the details");
    } else {
      let localUsers = localStorage.getItem("users");
      const data = {
        name: name,
        email: email,
        password: password,
      };
      if (localUsers) {
        let parsedUsers = JSON.parse(localUsers);
        parsedUsers.push(data);
        localStorage.setItem("users", JSON.stringify(parsedUsers));
      } else {
        let sendingUsers = [data];
        localStorage.setItem("users", JSON.stringify(sendingUsers));
      }

      history.push("/login");
    }
  };

  return (
    <div className="container">
      <h1>Sign Up</h1>
      <div className="name">
        <label
          style={{
            fontWeight: "bolder",
            paddingBottom: 10,
            color: "rgb(121, 214, 137)",
          }}
        >
          Name
        </label>
        <br />
        <input
          type="text"
          name="name"
          value={name}
          placeholder="Type your name"
          className="user-name"
          onChange={handleName}
        ></input>
      </div>

      <div className="email">
        <label
          style={{
            fontWeight: "bolder",
            paddingBottom: 10,
            color: "rgb(121, 214, 137)",
          }}
        >
          Email
        </label>
        <br />
        <input
          type="email"
          name="name"
          value={email}
          placeholder="Type your email"
          className="user-email"
          onChange={handleEmail}
        ></input>
      </div>
      <div className="password">
        <label
          style={{
            fontWeight: "bolder",
            paddingBottom: 10,
            color: "rgb(121, 214, 137)",
          }}
        >
          Password{" "}
        </label>
        <br />
        <input
          type="password"
          name="name"
          value={password}
          placeholder="Type your password"
          className="user-password"
          onChange={handlePassword}
        ></input>
      </div>
      <div>
        <button className="btn" onClick={handleSignUp}>
          Sign Up
        </button>
      </div>
    </div>
  );
}

export default SignUp;
