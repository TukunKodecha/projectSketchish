export const isLoggedIn = () => {
  let a = localStorage.getItem("isAuthenticated");
  if (a) {
    return true;
  }
  return false;
};
